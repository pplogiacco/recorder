/*************************************************************************
 *  � 2013 Microchip Technology Inc.                                       
 *  
 *  Project Name:    Class B Library Demo
 *  FileName:        All Tests Demo Main.c
 *  Dependencies:    system.h, classb.h
 *  Processor:       PIC24, dsPIC
 *  Compiler:        XC16
 *  IDE:             MPLAB� X                        
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *  Description:     This demo shows an usage example of all class B library
 *                   functions.
 *                   
 *************************************************************************/
/**************************************************************************
 * MICROCHIP SOFTWARE NOTICE AND DISCLAIMER: You may use this software, and 
 * any derivatives created by any person or entity by or on your behalf, 
 * exclusively with Microchip's products in accordance with applicable
 * software license terms and conditions, a copy of which is provided for
 * your referencein accompanying documentation. Microchip and its licensors 
 * retain all ownership and intellectual property rights in the 
 * accompanying software and in all derivatives hereto. 
 * 
 * This software and any accompanying information is for suggestion only. 
 * It does not modify Microchip's standard warranty for its products. You 
 * agree that you are solely responsible for testing the software and 
 * determining its suitability. Microchip has no obligation to modify, 
 * test, certify, or support the software. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE, ITS INTERACTION WITH 
 * MICROCHIP'S PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY 
 * APPLICATION. 
 * 
 * IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, 
 * TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), STRICT 
 * LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, 
 * SPECIAL, PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, 
 * FOR COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, 
 * HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY 
 * OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWABLE BY LAW, 
 * MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS 
 * SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID 
 * DIRECTLY TO MICROCHIP FOR THIS SOFTWARE. 
 * 
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF 
 * THESE TERMS. 
 *************************************************************************/

#include "system.h"
#include "classb.h"

#define RAM_TEST_BLOCK_LENGTH    512 // Bytes
#define FLASH_TEST_BLOCK_LENGTH  512 // Addressable Bytes

CLASSBRESULT RAMTestTask()
{
// 512 bytes buffer at the start of RAM
static uint16_t __attribute__((address(__DATA_BASE), noload)) marchTestBuffer[RAM_TEST_BLOCK_LENGTH/sizeof(uint16_t)];     
static uint16_t address = __DATA_BASE;
uint16_t        length  = RAM_TEST_BLOCK_LENGTH;

    // Length of the last RAM block can be less than the buffer length.
    if(length > (((uint16_t)__DATA_BASE+(uint16_t)__DATA_LENGTH)-address))
    {
        length = (((uint16_t)__DATA_BASE+(uint16_t)__DATA_LENGTH)-address);
    }

    // March tests buffer is located at the RAM start.
    if((uint16_t*)address == marchTestBuffer)
    {
        // Test buffer for march tests.
        
        // Checker Board test
        if(CLASSB_RAMCheckerboardTest(address,  // start address (must be aligned by word (2 bytes))
                                      length))  // length in bytes (must be aligned by 4 bytes)
        {
            return CLASSB_TEST_FAIL;
        }

        // March C test.
        if(CLASSB_RAMMarchCTest(address, // start address (must be aligned by word (2 bytes))
                                length,  // byte length (must be even number)
                                0,       // buffer is not specified, the memory will be cleared
                                false))  //
        {
            return CLASSB_TEST_FAIL;
        }

        // March C Minus test.
        if(CLASSB_RAMMarchCTest(address, // start address (must be aligned by word (2 bytes))
                                length,  // byte length (must be even number)
                                0,       // buffer is not specified, the memory will be cleared
                                true))   // minus algorithm
        {
            return CLASSB_TEST_FAIL;
        }

        // March B test.
        if(CLASSB_RAMMarchBTest(address, // start address (must be aligned by word (2 bytes))
                                length,  // byte length (must be even number)
                                0))      // buffer is not specified, the memory will be cleared
        {
            return CLASSB_TEST_FAIL;
        }

        // Move to the next memory block.
        address += length;

        // If was last RAM block, move to the RAM start.
        if(address == ((uint16_t)__DATA_BASE+(uint16_t)__DATA_LENGTH))
        {
            address = __DATA_BASE;
        }
     
        return CLASSB_TEST_PASS;
    }

    // Test RAM block saving its content in the buffer.
        
    // Checker Board test
    if(CLASSB_RAMCheckerboardTest(address, // start address (must be aligned by word (2 bytes))
                                  length)) // length in bytes (must be aligned by 4 bytes)
    {
        return CLASSB_TEST_FAIL;
    }

    // March C test.
    if(CLASSB_RAMMarchCTest(address,         // start address (must be aligned by word (2 bytes))
                            length,          // byte length (must be even number)
                            marchTestBuffer, // buffer to save the memory content
                            false))          // 
    {
        return CLASSB_TEST_FAIL;
    }

    // March C Minus test.
    if(CLASSB_RAMMarchCTest(address,         // start address (must be aligned by word (2 bytes))
                            length,          // byte length (must be even number)
                            marchTestBuffer, // buffer to save the memory content
                            true))           // minus algorithm
    {
        return CLASSB_TEST_FAIL;
    }

    // March B test.
    if(CLASSB_RAMMarchBTest(address,          // start address (must be aligned by word (2 bytes))
                            length,           // byte length (must be even number)
                            marchTestBuffer)) // buffer to save the memory content
    {
        return CLASSB_TEST_FAIL;
    }

    // Move to the next memory block.
    address += length;

    // If was last RAM block, move to the RAM start.
    if(address >= ((uint16_t)__DATA_BASE+(uint16_t)__DATA_LENGTH))
    {
        address = __DATA_BASE;
    }
     
    return CLASSB_TEST_PASS;
}

CLASSBRESULT FlashTestTask()
{
static  uint16_t correctCRC = -1;
static  uint16_t crc     = -1;
static  uint32_t address = __PROGRAM_BASE;
// Tested block size in program counter units (addressable bytes).
uint32_t         length = FLASH_TEST_BLOCK_LENGTH;

    // Length of the last RAM block can be less than the buffer length.
    if(length > ((__PROGRAM_BASE+__PROGRAM_LENGTH)-address))
    {
        length = ((__PROGRAM_BASE+__PROGRAM_LENGTH)-address);
    }

    // Calculate CRC of the flash memory block.
    crc = CLASSB_CRCFlashTest(address, // start address (must be aligned by word (2 bytes))
                              length,  // length in program counter units (addressable bytes, must be even)
                              crc);    // initial/previous CRC to continue calculations  


    // Move to the next memory block.
    address += length;

    // If it was last flash block, move to the flash start.
    // Compare CRC with pre-calculated value.
    if(address == (__PROGRAM_BASE+__PROGRAM_LENGTH))
    {
        if(correctCRC != -1)
        { 
            if(crc != correctCRC)
            {
                return CLASSB_TEST_FAIL;
            }
        }else{
            // Assume that the first cycle CRC is correct.
            correctCRC = crc; 
        }
        address = __PROGRAM_BASE; // Move to the flash start.
        crc = -1; // Set initial value for the next cycle.
    }
     
    return CLASSB_TEST_PASS;
}

void MainApplicationTask()
{
    // APPLICATION CODE SHOULD BE HERE.
    SysLedsChaser();
}

int main(){
    
   // Check for a watchdog timer timeout error.  
   if(RCONbits.WDTO == 1)
   {
       RCONbits.WDTO = 0;
       // ERROR IS DETECTED
       asm volatile ("bra $+0");
   }

   // Initialize board hardware.
   SysBoardInit();  

   // Entire RAM march test
   if(CLASSB_EntireRAMMarchBTest())
   {
      // ERROR IS DETECTED
     asm volatile ("bra $+0");
   }      

   while(1)
   {   
       // CPU Program Counter test.
       // Should be used with a watchdog timer.   
       if(CLASSB_CPUPCTest())
       {
           // ERROR IS DETECTED
           asm volatile ("bra $+0");
       }

       // Clear watchdog.
       ClrWdt();

       // CPU Registers test.
       if(CLASSB_CPURegistersTest())
       {
           // ERROR IS DETECTED
           asm volatile ("bra $+0");
       }

       // Clear watchdog.
       ClrWdt();
       
       // Clock test.
       // Interrupts are disabled during this test.
       if(CLASSB_ClockTest(CLOCK_FREQUENCY, // CPU clock frequency (MIPS)
                           SECONDARY_CLOCK_FREQUENCY,  // reference (low) frequency
                           55,  // 5.5% tolerance limit
                           &TMR1)) // Timer 1 is used to count reference clock cycles
       {
           // ERROR IS DETECTED
           asm volatile ("bra $+0");
       }

       // Clear watchdog.
       ClrWdt();

       // Run Flash test task periodically.      
       if(FlashTestTask())
       {
           // FLASH ERROR IS DETECTED HERE.
           asm volatile ("bra $+0");

       }

       // Clear watchdog.
       ClrWdt();
       
       // Run RAM test task periodically.    
    //   if(RAMTestTask())
       {
           // RAM ERROR IS DETECTED HERE.
      //     asm volatile ("bra $+0");

       }

       // Clear watchdog.
       ClrWdt();

       // Run main application.
       MainApplicationTask();

       // Clear watchdog.
       ClrWdt();

   } // end of while
   
   return 1;
}
