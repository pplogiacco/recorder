/*************************************************************************
 *  � 2013 Microchip Technology Inc.                                       
 *  
 *  Project Name:    Class B Library
 *  FileName:        system.h
 *  Dependencies:    xc.h, stdint.h
 *  Processor:       PIC24, dsPIC
 *  Compiler:        XC16
 *  IDE:             MPLAB� X                        
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *  Description:     This header contains hardware depended definitions.
 *************************************************************************/
/**************************************************************************
 * MICROCHIP SOFTWARE NOTICE AND DISCLAIMER: You may use this software, and 
 * any derivatives created by any person or entity by or on your behalf, 
 * exclusively with Microchip's products in accordance with applicable
 * software license terms and conditions, a copy of which is provided for
 * your referencein accompanying documentation. Microchip and its licensors 
 * retain all ownership and intellectual property rights in the 
 * accompanying software and in all derivatives hereto. 
 * 
 * This software and any accompanying information is for suggestion only. 
 * It does not modify Microchip's standard warranty for its products. You 
 * agree that you are solely responsible for testing the software and 
 * determining its suitability. Microchip has no obligation to modify, 
 * test, certify, or support the software. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE, ITS INTERACTION WITH 
 * MICROCHIP'S PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY 
 * APPLICATION. 
 * 
 * IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, 
 * TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), STRICT 
 * LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, 
 * SPECIAL, PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, 
 * FOR COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, 
 * HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY 
 * OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT ALLOWABLE BY LAW, 
 * MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS 
 * SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID 
 * DIRECTLY TO MICROCHIP FOR THIS SOFTWARE. 
 * 
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF 
 * THESE TERMS. 
 *************************************************************************/

#ifndef _SYSTEM_H_
#define _SYSTEM_H_

#include <xc.h>
#include <stdint.h>

/****************************************************************************
  System oscillator frequency. 
  ***************************************************************************/
#define CLOCK_FREQUENCY  80000000UL
#define SECONDARY_CLOCK_FREQUENCY  32768UL // in Hz

#if !defined ( __C30__ )
    #error This system file is for PIC24/dsPIC only.
#endif

#ifdef _SYSTEM_C_
// PRIVATE

// DSPIC33FJ256MC710A Configuration Bit Settings

// 'C' source line config statements

// FBS
#pragma config BWRP = WRPROTECT_OFF     // Boot Segment Write Protect (Boot Segment may be written)
#pragma config BSS = NO_FLASH           // Boot Segment Program Flash Code Protection (No Boot program Flash segment)
#pragma config RBS = NO_RAM             // Boot Segment RAM Protection (No Boot RAM)

// FSS
#pragma config SWRP = WRPROTECT_OFF     // Secure Segment Program Write Protect (Secure Segment may be written)
#pragma config SSS = NO_FLASH           // Secure Segment Program Flash Code Protection (No Secure Segment)
#pragma config RSS = NO_RAM             // Secure Segment Data RAM Protection (No Secure RAM)

// FGS
#pragma config GWRP = OFF               // General Code Segment Write Protect (User program memory is not write-protected)
#pragma config GSS = OFF                // General Segment Code Protection (User program memory is not code-protected)

// FOSCSEL
#pragma config FNOSC = FRC              // Oscillator Mode (Internal Fast RC (FRC) with divide by N)
#pragma config IESO = ON                // Two-speed Oscillator Start-Up Enable (Start up with FRC, then switch)

// FOSC
#pragma config POSCMD = HS              // Primary Oscillator Source (Primary Oscillator Disabled)
#pragma config OSCIOFNC = OFF           // OSC2 Pin Function (OSC2 pin has clock out function)
#pragma config FCKSM = CSECMD           // Clock Switching and Monitor (Both Clock Switching and Fail-Safe Clock Monitor are disabled)

// FWDT
#pragma config WDTPOST = PS32768        // Watchdog Timer Postscaler (1:32,768)
#pragma config WDTPRE = PR128           // WDT Prescaler (1:128)
#pragma config PLLKEN = ON              // PLL Lock Enable bit (Clock switch to PLL source will wait until the PLL lock signal is valid.)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Watchdog Timer in Non-Window mode)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog timer enabled/disabled by user software)

// FPOR
#pragma config FPWRT = PWR128           // POR Timer Value (128ms)
#pragma config LPOL = ON                // Low-side PWM Output Polarity (Active High)
#pragma config HPOL = ON                // Motor Control PWM High Side Polarity bit (PWM module high side output pins have active-high output polarity)
#pragma config PWMPIN = ON              // Motor Control PWM Module Pin Mode bit (PWM module pins controlled by PORT register at device Reset)

// FICD
#pragma config ICS = PGD1               // Comm Channel Select (Communicate on PGC1/EMUC1 and PGD1/EMUD1)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG is Disabled)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>

/****************************************************************************
  Macro:
    SysLedsInit()

  Summary:
    Initializes board's LEDs.

  Description:
    Initializes board's LEDs.
 
  Precondition:
    None.

  Parameters:
    None.

  Returns:
    None.

  Remarks:
    None.
  ***************************************************************************/
#define SysLedsInit()  {LATA &= ~0x00ff; TRISA &= ~0x00ff;}

/****************************************************************************
  Macro:
    SysDelay1Ms()

  Summary:
    Delay execution on 1 mS.

  Description:
    Delay execution on 1 mS.
 
  Precondition:
    None.

  Parameters:
    None.

  Returns:
    None.

  Remarks:
    None.
  ***************************************************************************/
#define SysDelay1Ms()  {asm volatile("repeat #10000 \n nop");\
asm volatile("repeat #10000 \n nop");\
asm volatile("repeat #10000 \n nop");\
asm volatile("repeat #10000 \n nop");}


#endif

// PUBLIC

// DEVICE RAM
#define RAM_START_ADDRESS   ((uint16_t)0x0850)
#define RAM_END_ADDRESS     ((uint16_t)0x8000)

// DEVICE FLASH
#define FLASH_START_ADDRESS  ((uint32_t)0x000000)
#define FLASH_END_ADDRESS    ((uint32_t)0x02AC00)

// LEDS CONTROL
#define Led0On()     {LATAbits.LATA0 = 1;}
#define Led0Off()    {LATAbits.LATA0 = 0;}

#define Led1On()     {LATAbits.LATA1 = 1;}
#define Led1Off()    {LATAbits.LATA1 = 0;}

#define Led2On()     {LATAbits.LATA2 = 1;}
#define Led2Off()    {LATAbits.LATA2 = 0;}

#define Led3On()     {LATAbits.LATA3 = 1;}
#define Led3Off()    {LATAbits.LATA3 = 0;}

#define Led4On()     {LATAbits.LATA4 = 1;}
#define Led4Off()    {LATAbits.LATA4 = 0;}

#define Led5On()     {LATAbits.LATA5 = 1;}
#define Led5Off()    {LATAbits.LATA5 = 0;}

#define Led6On()     {LATAbits.LATA6 = 1;}
#define Led6Off()    {LATAbits.LATA6 = 0;}

#define Led7On()     {LATAbits.LATA7 = 1;}
#define Led7Off()    {LATAbits.LATA7 = 0;}

#define Led_ALLOn()  {LATA |= 0x00ff;}
#define Led_ALLOff() {LATA &= ~0x00ff;}


/****************************************************************************
  Function:
    void SysDelayMs(uint16_t delay)

  Summary:
    Delay execution on defined time.

  Description:
    Delay execution on defined time.
 
  Precondition:
    None

  Parameters:
    delay  - delay time in mS.

  Returns:
    None.

  Remarks:
    None.
  ***************************************************************************/
void SysDelayMs(uint16_t delay);

/****************************************************************************
  Macro:
    SysLedsChaser()

  Summary:
    Turn on and off all LEDs in sequence.

  Description:
    Turn on and off all LEDs in sequence.
 
  Precondition:
    None.

  Parameters:
    None.

  Returns:
    None.

  Remarks:
    None.
  ***************************************************************************/
#define SysLedsChaser() {\
Led0On(); SysDelayMs(20);Led0Off();Led1On(); SysDelayMs(20);Led1Off();Led2On(); SysDelayMs(20);Led2Off();Led3On(); SysDelayMs(20);Led3Off();\
Led4On(); SysDelayMs(20);Led4Off();Led5On(); SysDelayMs(20);Led5Off();Led6On(); SysDelayMs(20);Led6Off();Led7On(); SysDelayMs(20);Led7Off();\
Led7On(); SysDelayMs(20);Led7Off();Led6On(); SysDelayMs(20);Led6Off();Led5On(); SysDelayMs(20);Led5Off();Led4On(); SysDelayMs(20);Led4Off();\
Led3On(); SysDelayMs(20);Led3Off();Led2On(); SysDelayMs(20);Led2Off();Led1On(); SysDelayMs(20);Led1Off();Led0On(); SysDelayMs(20);Led0Off();\
}

/****************************************************************************
  Function:
    void SysBoardInit(void)

  Summary:
    Initializes the board hardware.

  Description:
    Initializes the board hardware.
 
  Precondition:
    None.

  Parameters:
    None.

  Returns:
    None.

  Remarks:
    None.
  ***************************************************************************/
void SysBoardInit(void);

#endif
