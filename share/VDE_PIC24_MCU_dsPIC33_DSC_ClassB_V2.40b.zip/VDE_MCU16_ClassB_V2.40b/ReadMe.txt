
Help file for the Class B library is located in "...\Microchip\Help" folder.


The demo projects are located in "...\Class B Demos" folder. The demo code is written for 
Explorer 16/32 Development Board (DM240001-2) with the following plug-in modules:

PIC24FJ128GA010 (MA240011),
PIC24FJ1024GB610 (MA240023),
dsPIC33FJ256MC710A (MA330013),
dsPIC33CK256MP508 (MA330042).

Demo code is written for the Explorer 16/32 Development Board (DM240001-2) with 
PIC24F or dsPIC33 processor plug-in modules (www.microchip.com/pims).

Application Note AN1778 describes the library of low-level software routines and 
hardware peripherals that simplify meeting IEC 60730 requirements for Class B Safety. 
Using this Class B Safety Software Library reduces development time because each 
function has been optimized and tested. 

Application Note AN1229 describes the Application Programming Interface (API) 
functions that are available in the Class B Safety Software Library and how 
to incorporate them in your project. It also describes the software routines 
that detect the occurrence of faults in a single channel CPU, developed in 
accordance with the IEC 60730 standard to support the Class B certification process. 
